from __future__ import print_function
import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import base64
import json
from subprocess import call

# If modifying these scopes, delete the file token.pickle.
#SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
SCOPES = ['https://www.googleapis.com/auth/gmail.labels','https://www.googleapis.com/auth/gmail.modify']

def main():
    """Shows basic usage of the Gmail API.
    Lists the user's Gmail labels.
    """
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('gmail', 'v1', credentials=creds)

    """
    # Call the Gmail API
    results = service.users().messages().list(userId='me', maxResults=10, labelIds=['IMPORTANT', 'CATEGORY_PERSONAL', 'INBOX']).execute()
    #labels = results.get('labels', [])
    messages = []
    messages_id = []
    if 'messages' in results:
        messages.extend(results['messages'])
    i=1
    
    while 'nextPageToken' in results and i<5:
        page_token = results['nextPageToken']
        results = service.users().messages().list(userId='me', maxResults=10, pageToken=page_token).execute()
        messages.extend(results['messages'])
        i += 1
    
    for x in messages:
        messages_id.append(x['id'])
    for ids in messages_id:
        #j=0
        #if i==8:
            #message0 = service.users().messages().get(userId='me', id=ids).execute()
        message = service.users().messages().get(userId='me', id=ids).execute()
        #print('Message headers: %s' % message['payload']['headers'])
        for champ in message['payload']['headers']:
            if champ['name'] == 'Subject':
                message_subject = champ['value']
            if champ['name'] == 'From':
                message_from = champ['value']
            if champ['name'] == 'To':
                message_to = champ['value']
            if champ['name'] == 'Date':
                message_date = champ['value']
        print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
        print("\tSubject : " + message_subject)
        print("\t" + message['snippet'])
        for champ in message['payload']['headers']:
            print(str(j) + " : " + champ['name'] + " ---> " + champ['value'])
            j+=1
        i+=1
    """

    # Idée : afficher les mails de la boite PRINCIPALE
    # les afficher 10 par 10
    # Menu : 
    #   - afficher le mail n°X
    #   - voir les 10 prochains mails
    #   - voir les 10 mails précédents
    # ---> Charger les 10 premiers mails
    # ---> Afficher le menu
    # ---> Enregistrer la réponse


    # ---> Charger les 10 premiers mails
    call(["../matrix", "gmail"])
    results = service.users().messages().list(userId='me', maxResults=10, labelIds=['IMPORTANT', 'INBOX']).execute()
    messages = []
    messages_id = []
    list_msg = []
    unread_msg = 0
    new_unread_msg = False
    if 'messages' in results:
        messages.extend(results['messages'])
    if 'nextPageToken' in results:
        page_token = results['nextPageToken']
    i=1
    for x in messages:
        messages_id.append(x['id'])
    for ids in messages_id:
        #j=0
        #if i==8:
            #message0 = service.users().messages().get(userId='me', id=ids).execute()
        message = service.users().messages().get(userId='me', id=ids).execute()
        list_msg.append(message)
        #print('Message headers: %s' % message['payload']['headers'])
        for champ in message['payload']['headers']:
            if champ['name'] == 'Subject':
                message_subject = champ['value']
            if champ['name'] == 'From':
                message_from = champ['value']
            if champ['name'] == 'To':
                message_to = champ['value']
            if champ['name'] == 'Date':
                message_date = champ['value']
        print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
        if 'UNREAD' in message['labelIds']:
            print("\tMAIL NON LU")
            unread_msg += 1
        print("\tObjet : " + message_subject)
        print("\t" + message['snippet'])
        i+=1
    pageActuel = 1
    nbPages = 1
    call(["../segment", str(unread_msg)])

    reponse = ""
    while reponse != "q":
        # Afficher le menu
        print("Que voulez-vous faire ?")
        print("\tAfficher le message X (renseigner le n°)")
        print("\tRéafficher la page actuel (r)")
        print("\tAfficher les 10 mails suivants (n)")
        print("\tAfficher les 10 mails précédents (p)")
        print("\tQuitter (q)")
        reponse = input("Votre réponse : ")
        if reponse.isdigit():
            ### Afficher le mail
            numero = int(reponse)
            if numero > len(messages) or numero < 1:
                print("Impossible de trouver le mail")
            else:
                # Affiche
                num = messages_id[numero-1]
                #message = service.users().messages().get(userId='me', id=num).execute()
                #print('Message headers: %s' % message['payload']['headers'])
                message = list_msg[numero - 1]
                for champ in message['payload']['headers']:
                    if champ['name'] == 'Subject':
                        message_subject = champ['value']
                    if champ['name'] == 'From':
                        message_from = champ['value']
                    if champ['name'] == 'To':
                        message_to = champ['value']
                    if champ['name'] == 'Date':
                        message_date = champ['value']
                print(str(numero) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
                print("\tObjet : " + message_subject)
                print("\t" + message['snippet'])
                if 'body' in message['payload'] and message['payload']['body']['size'] != 0:
                    #print(json.dumps(message, indent=4))
                    print(base64.urlsafe_b64decode(message['payload']["body"]["data"]).decode("utf-8"))
                elif 'data' in message['payload']['parts'][0]["body"]:
                    print(base64.urlsafe_b64decode(message['payload']['parts'][0]["body"]["data"]).decode("utf-8"))
                elif 'parts' in message['payload']['parts'][0]:
                    if 'data' in message['payload']['parts'][0]['parts'][0]['body']:
                        print(base64.urlsafe_b64decode(message['payload']['parts'][0]['parts'][0]["body"]["data"]).decode("utf-8"))
                else:
                    print(json.dumps(message, indent=4))
                    print("pas de body pour ce mail !")
                if 'UNREAD' in message['labelIds']:
                    # Enlever le label 'UNREAD'
                    msg_labels = {'removeLabelIds': ['UNREAD'], 'addLabelIds': []}
                    message_modify = service.users().messages().modify(userId='me', id=messages_id[numero-1], body=msg_labels).execute()
                    # Refresh le mail
                    #print(service.users().messages().get(userId='me', id=messages_id[numero-1]).execute())
                    list_msg[numero-1] = service.users().messages().get(userId='me', id=messages_id[numero-1]).execute()
                    unread_msg -= 1
                    call(["../segment", str(unread_msg)])
                call(["../lcd", "From : " + message_from, "To : " + message_to, "Date : " + message_date, "Objet : " + message_subject])
        elif reponse == "r":
            # Réafficher la page
            for i in range(pageActuel*10-9, pageActuel*10+1):
                message = list_msg[i-1]
                #print('Message headers: %s' % message['payload']['headers'])
                for champ in message['payload']['headers']:
                    if champ['name'] == 'Subject':
                        message_subject = champ['value']
                    if champ['name'] == 'From':
                        message_from = champ['value']
                    if champ['name'] == 'To':
                        message_to = champ['value']
                    if champ['name'] == 'Date':
                        message_date = champ['value']
                print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
                if 'UNREAD' in message['labelIds']:
                    print("\tMAIL NON LU")
                print("\tObjet : " + message_subject)
                print("\t" + message['snippet'])
                
        elif reponse == "n":
            ### Afficher les 10 mails suivants
            # Tester s'il faut charger des messages
            if pageActuel == nbPages:
                # On charge
                messagesNextPage = []
                messages_idNextPage = []
                results = service.users().messages()\
                .list(userId='me', maxResults=10, labelIds=['IMPORTANT', 'INBOX'], pageToken=page_token).execute()
                if 'messages' in results:
                    messages.extend(results['messages'])
                    messagesNextPage = results['messages']
                if 'nextPageToken' in results:
                    page_token = results['nextPageToken']
                for x in messagesNextPage:
                    messages_id.append(x['id'])
                    messages_idNextPage.append(x['id'])
                i=pageActuel*10+1
                for ids in messages_idNextPage:
                    #j=0
                    #if i==8:
                        #message0 = service.users().messages().get(userId='me', id=ids).execute()
                    message = service.users().messages().get(userId='me', id=ids).execute()
                    list_msg.append(message)
                    #print('Message headers: %s' % message['payload']['headers'])
                    for champ in message['payload']['headers']:
                        if champ['name'] == 'Subject':
                            message_subject = champ['value']
                        if champ['name'] == 'From':
                            message_from = champ['value']
                        if champ['name'] == 'To':
                            message_to = champ['value']
                        if champ['name'] == 'Date':
                            message_date = champ['value']
                    print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
                    if 'UNREAD' in message['labelIds']:
                        print("\tMAIL NON LU")
                        unread_msg += 1
                        new_unread_msg = True
                    print("\tObjet : " + message_subject)
                    print("\t" + message['snippet'])
                    i+=1
                pageActuel += 1
                nbPages += 1
                if new_unread_msg:
                    call(["../segment", str(unread_msg)])
            else:
                # On ne charge pas, on récupère 
                #messagesPage = messages[pageActuel*10:pageActuel*10+10]
                #messages_idPage = messages_id[pageActuel*10:pageActuel*10+10]
                #i = pageActuel*10+1
                for i in range(pageActuel*10+1, pageActuel*10+11):
                    #j=0
                    #if i==8:
                        #message0 = service.users().messages().get(userId='me', id=ids).execute()
                    #message = service.users().messages().get(userId='me', id=ids).execute()
                    message = list_msg[i-1]
                    #print('Message headers: %s' % message['payload']['headers'])
                    for champ in message['payload']['headers']:
                        if champ['name'] == 'Subject':
                            message_subject = champ['value']
                        if champ['name'] == 'From':
                            message_from = champ['value']
                        if champ['name'] == 'To':
                            message_to = champ['value']
                        if champ['name'] == 'Date':
                            message_date = champ['value']
                    print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
                    if 'UNREAD' in message['labelIds']:
                        print("\tMAIL NON LU")
                    print("\tObjet : " + message_subject)
                    print("\t" + message['snippet'])
                    #i+=1
                pageActuel += 1

        elif reponse == "p":
            ### Afficher les 10 mails précédents
            if pageActuel < 2:
                print("Impossible !")
            else:
                pageActuel -= 1
                #messagesPage = messages[pageActuel*10:pageActuel*10+10]
                #messages_idPage = messages_id[pageActuel*10:pageActuel*10+10]
                #i=pageActuel*10-9
                for i in range(pageActuel*10-9, pageActuel*10+1):
                    #j=0
                    #if i==8:
                        #message0 = service.users().messages().get(userId='me', id=ids).execute()
                    #message = service.users().messages().get(userId='me', id=ids).execute()
                    message = list_msg[i-1]
                    #print('Message headers: %s' % message['payload']['headers'])
                    for champ in message['payload']['headers']:
                        if champ['name'] == 'Subject':
                            message_subject = champ['value']
                        if champ['name'] == 'From':
                            message_from = champ['value']
                        if champ['name'] == 'To':
                            message_to = champ['value']
                        if champ['name'] == 'Date':
                            message_date = champ['value']
                    print(str(i) + " : From " + message_from + " to " + message_to + ", Date : " + message_date)
                    if 'UNREAD' in message['labelIds']:
                        print("\tMAIL NON LU")
                    print("\tObjet : " + message_subject)
                    print("\t" + message['snippet'])
                    #i+=1

        elif reponse == "q":
            print("On quitte !")
            
        else:
            ### ...
            print("erreur....")

    #print(json.dumps(message0, indent=4))
    #print(message0['payload']['parts'][1]["body"]["data"])
    #print(base64.urlsafe_b64decode(message0['payload']['parts'][0]["body"]["data"]).decode("utf-8"))

    #print(messages_id)

    """
    if not labels:
        print('No labels found.')
    else:
        print('Labels:')
        for label in labels:
            print(label['name'])
    """

if __name__ == '__main__':
    main()