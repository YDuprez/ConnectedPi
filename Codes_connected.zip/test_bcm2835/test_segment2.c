#include <stdio.h> 
#include <unistd.h> 
#include <stdint.h> 
#include <wiringPi.h> 
#include <wiringPiI2C.h> 

#include <sys/time.h> 

#include <stdbool.h> 

#define HT16K33_BLINK_CMD 0x80 
#define HT16K33_BLINK_DISPLAYON 0x01 
#define HT16K33_BLINK_OFF 0 
#define HT16K33_BLINK_2HZ  1 
#define HT16K33_BLINK_1HZ  2 
#define HT16K33_BLINK_HALFHZ  3 

#define HT16K33_CMD_BRIGHTNESS 0xE0 

#define SEVENSEG_DIGITS 5 

// déclaration globale 
uint16_t displaybuffer[12]; 

static const uint8_t numbertable[] = { 
	0x3F, /* 0 */ 
	0x06, /* 1 */ 
	0x5B, /* 2 */ 
	0x4F, /* 3 */ 
	0x66, /* 4 */ 
	0x6D, /* 5 */ 
	0x7D, /* 6 */ 
	0x07, /* 7 */ 
	0x7F, /* 8 */ 
	0x6F, /* 9 */ 
	0x77, /* a */ 
	0x7C, /* b */ 
	0x39, /* C */ 
	0x5E, /* d */ 
	0x79, /* E */ 
	0x71, /* F */ 
}; 

void setBrightness(int fd, uint8_t b) { 
  if (b > 15) b = 15; 
  wiringPiI2CWrite(fd, HT16K33_CMD_BRIGHTNESS | b); 
} 

void blinkRate(int fd, uint8_t b) { 
  if (b > 3) b = 0; // turn off if not sure 
  wiringPiI2CWrite(fd, HT16K33_BLINK_CMD | HT16K33_BLINK_DISPLAYON | (b << 1)); 
} 

void begin(int fd) { 
  wiringPiI2CWrite(fd, 0x21); 
  blinkRate(fd, HT16K33_BLINK_OFF); 
  setBrightness(fd, 15); // max brightness 
} 

void writeDisplay(int fd, int offset) { 
  uint8_t addr = (uint8_t) 0x00;	 
  uint8_t i=0; 
  for(i=0 ; i<4 ; i++) { 
	if(i==2) // 2 points 
	    addr+=2;   
    wiringPiI2CWriteReg8(fd, addr++, displaybuffer[i+offset] & 0xFF); 
    wiringPiI2CWriteReg8(fd, addr++, displaybuffer[i+offset] >> 8);  
  }  
} 

void clear(void) { 
  uint8_t i=0; 
  for (i=0; i<12; i++) { 
    displaybuffer[i] = 0; 
  } 
} 

void writeDigitRaw(uint8_t d, uint8_t bitmask) { 
  if (d > 11) return; 
  displaybuffer[d] = bitmask; 
} 

void writeDigitNum(uint8_t d, uint8_t num, bool dot) { 
  if (d > 11) return; 
  writeDigitRaw(d, numbertable[num] | (dot << 7)); 
} 


int main(int argc, char const *argv[]) 
{ 
	if (argc < 2) {
		printf("Il manque un argument ! (nombre entre 0 et 9999)\n");
		exit(0);
	}
	if (atoi(argv[1]) < 0 || atoi(argv[1]) > 9999) {
		printf("L'argument doit être compris entre 0 et 9999 !\n");
		exit(1);
	}
	int digit0, digit1, digit2, digit3;
	int reste;
	int nombre = atoi(argv[1]);

	// setup 
	int fda = wiringPiI2CSetup(0x70); 
	//int fdb = wiringPiI2CSetup(0x71); 
	//int fdc = wiringPiI2CSetup(0x72); 
	 
	//printf("fda : %d \n", fda); 
	//printf("fdb : %d \n", fdb); 
	//printf("fdc : %d \n", fdc); 

	// begin 
	begin(fda); 
	//begin(fdb); 
	//begin(fdc); 
	 
	// clear 
	clear(); 

	if(nombre >= 0 && nombre <= 9) {
		digit3 = nombre;
		writeDigitNum(3, digit3, false);
	} else if(nombre >= 10 && nombre <= 99) {
		digit2 = nombre/10;
		digit3 = nombre%10;
		writeDigitNum(2, digit2, false);
		writeDigitNum(3, digit3, false);
	} else if (nombre >= 100 && nombre <= 999) {
		digit1 = nombre/100;
		reste = nombre%100;
		digit2 = reste/10;
		digit3 = reste%10;
		writeDigitNum(1, digit1, false);
		writeDigitNum(2, digit2, false);
		writeDigitNum(3, digit3, false);		
	} else if(nombre >= 1000 && nombre <= 9999) {
		digit0 = nombre/1000;
		reste = nombre%1000;
		digit1 = reste/100;
		reste = reste%100;
		digit2 = reste/10;
		digit3 = reste%10;
		writeDigitNum(0, digit0, false);
		writeDigitNum(1, digit1, false);
		writeDigitNum(2, digit2, false);
		writeDigitNum(3, digit3, false);
	}
	writeDisplay(fda, 0);
        // loop 
	int num = 0; 
	/*
	while(true) { 
		// write first display 
		writeDigitNum(0, num, false); 
		writeDigitNum(1, (num + 1) % 10, false); 
		writeDigitNum(2, (num + 2) % 10, false); 
		writeDigitNum(3, (num + 3) % 10, false); 
		 
                // write second display 
		//writeDigitNum(4, (num + 4) % 10, false); 
		//writeDigitNum(5, (num + 5) % 10, false); 
		//writeDigitNum(6, (num + 6) % 10, false); 
		//writeDigitNum(7, (num + 7) % 10, false); 
		 
                // write third display 
		//writeDigitNum(8, (num + 8) % 10, false); 
		//writeDigitNum(9, (num + 9) % 10, false); 
		//writeDigitNum(10, (num + 10) % 10, false); 
		//writeDigitNum(11, (num + 11) % 10, false); 
		//	 
		// write displays 
		writeDisplay(fda, 0); 
		//writeDisplay(fdb, 4); 
		//writeDisplay(fdc, 8); 
		 
		// sleep 
		sleep(1); // second 
		 
		// increment 
		num++; 
		num %= 10;  
	} */
	return 1; 
} 
